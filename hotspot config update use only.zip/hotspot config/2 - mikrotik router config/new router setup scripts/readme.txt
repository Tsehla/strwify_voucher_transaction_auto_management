mikrotik router setup script optimized.

read through en change details where necessary

try to use unique hotspot names for hotspot even those in same location i.e orangefarm_extension_4_sibeko_street,  orangefarm_extension_4_tsehla_street,  orangefarm_extension_4_nkhi_street, etc. this will affect certain things regarding restrictions, unlss you intent to treat them as singular and dont have need for hotspot trial  usages related restrictions,  [ this is or was for ability to set restriction on hotspot free usrs, like ban users for few minutes if they are over using data, or automaticall change download speed for users who have reached usage limit over a certain period of time etc ], this feature doesnt apply to free usage produced by radius server program/app developed for this program/app, so this is to apply to mikrotk trial users, as intention is to offer unlimited internet but control system perfomance for good user experience by adding temporary restriction to usages either by how many users are in the system currently or by how much data is used over time.. this i have not yet developed but have laid foundation for it in the app already...



to import code to mikrotik terminal use

----
import verbose=yes name_of_script.rsc
---

if problem or error., just open script in txt and copy past everythin on terminal, there may be issues with wallgarden links not being added using this method 

---

to access  webfig you need to login first.
to access winbox you need to login, then access webfig on port 81, then go to services and allow port for winbox

-- it may be best to change scripts values to reflect your like wall garden and radius server before uploading script to router and applying, this is so if the router locks you out, you can login en access webfig 

-- there is a trial user on streetwifiy.za

