to use this script,

reset router to [ home ap ] and select [ bridge all port checkmark ];

ensure the new bridge name in [interface] is called [ bridge ] not bridge1 etc. This is useful if you want to reset the router without having to connect it to network port to repair after reset