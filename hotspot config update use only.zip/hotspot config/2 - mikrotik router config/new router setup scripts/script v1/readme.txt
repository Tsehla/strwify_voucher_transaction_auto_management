to run this script, 
reset the router in [ system ] using [ reset configuration ], ensure to check box [ no default configuration ] is selectd

- tip:
to avoid being locked out, on reset menu select the configuration script in this folder to be run after reset, this way you be able to login if radius details you already defined in the script.