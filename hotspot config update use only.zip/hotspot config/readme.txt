this are thing needed to configure and upload on a mikrotik router, if router not new, reset router
folders here are numbered, best to start in numbering order and do as folders contents say